<?php

echo "THIS IS OUR FOOTET - THE END";


echo '</body></html>';

$mysqli->close();
?>