<?php

echo "<div class = \"zagolovok\">**********************************  END  ************************************</div>";

echo "<script type=\"text/javascript\" src=\"js/ajax_query.js\"></script>";
echo '</body></html>';

$mysqli->close();
?>