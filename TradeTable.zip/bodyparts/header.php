<!DOCTYPE html>
<html lang="ru">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>АНМАКС ОНЛАЙН</title>
    <link rel = "stylesheet" href = "https://cdnjs.cloudflare.com/ajax/libs/normalize/8.0.1/normalize.min.css">
    <!-- <link rel = "stylesheet" href = "css/style1.css">
    <link rel = "stylesheet" href="css/promo.css">
    <link rel = "stylesheet" href = "css/menu.css">
    <link rel = "stylesheet" href = "css/media767.css">
    <link rel = "stylesheet" href = "css/item.css"> -->
    <link rel = "stylesheet" href = "css/for_all_class.css">
    <link rel = "stylesheet" href = "css/drawtable.css">
    <link rel = "stylesheet" href = "css/info_company.css">
    <link rel = "stylesheet" href = "css/modal.css"> 
    <link rel = "stylesheet" href = "css/mobile.css">
    
    <script type="text/javascript" src="js/jquery/jquery-3.6.0.min.js"></script>
    <!-- <script type="text/javascript" src="js/ajax_query.js"></script> -->




</head>

<body>
   
   