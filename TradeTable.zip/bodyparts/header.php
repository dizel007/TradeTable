<!DOCTYPE html>
<html lang="ru">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Таблица коммерческих предложений</title>
    <link rel = "stylesheet" href = "css/style1.css">
    <link rel = "stylesheet" href="css/promo.css">
    <link rel = "stylesheet" href = "css/menu.css">
    <link rel = "stylesheet" href = "css/media767.css">
    <link rel = "stylesheet" href = "css/item.css">
    <link rel = "stylesheet" href = "css/drawtable.css">
    <link rel = "stylesheet" href = "css/modal.css">
    <script src="js/include_html.js"></script>
    

</head>

<body>

   
   