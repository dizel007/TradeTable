<?php
include_once ("functions/make_arr_from_obj.php");
include_once ("functions/select_from_db.php");
include_once ("functions/print_our_table.php"); // подлючаем функцию вывода таблциы
include_once ("functions/print_about_comp.php");





?>