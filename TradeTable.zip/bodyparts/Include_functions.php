<?php
include_once ("functions/makeArrFromObj.php");
include_once ("functions/SelectFromDB.php");
include_once ("functions/printOurTable.php"); // подлючаем функцию вывода таблциы





?>