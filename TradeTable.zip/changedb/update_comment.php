<?php
require_once "../connect_db.php";
require_once "../functions/make_arr_from_obj.php";
require_once "../functions/make_comment.php";
require_once "../functions/get_user.php";

// Обновляем данные в талиблице. $typeQuery - выбоо столбца, который будем редактировать. $id -  ИД строки которую будем редактировать
$id = $_GET['id'];
$id=htmlspecialchars($id);
$typeQuery=$_GET['typeQuery'];
$typeQuery=htmlspecialchars($typeQuery);

$user_login = GetUser($mysqli); // Получаем имя пользователья

  $sql = "SELECT * FROM reestrkp where id = '$id'";
  $fQuery = $mysqli->query($sql);
  $my_id_arr = makeArrayFromObj($fQuery) ;




// echo "typeQuery =".$typeQuery."<br>";
// Выбираем какой столбец редактируем 
// если Изменяем комментарий
    if ($typeQuery==11) {
      $changeColumn = 'Comment';
      $newPerem = makeComment($my_id_arr, $user_login);
      
       
      //     if (isset($_POST['text'])) 
      //     { 
      //       $newPerem = $_POST['text'] ; // цепляем дату внесения комметнария
      //       $newPerem =  trim ( $newPerem , $character_mask = " \t\n\r\0\x0B"); // убипаем все лишние пробелы и переносы
      //       if ($newPerem != $my_id_arr[0]['Comment']) { // Проверяем изменился ли коммень
 
              
      //         if ($newPerem !='')  $newPerem ="@!" . date('Y-m-d')."(".$user_login."): ". $newPerem; // цепляем дату внесения комметнария
      //   }


           
          
      //                 // $newPerem = str_replace("\r\n" , "", $newPerem);
      //     }
      }

  // если Изменяем контакты Заказчика
  if ($typeQuery==6) {
    $changeColumn = 'ContactCustomer';
        if (isset($_POST['text'])) 
        { 
          $newPerem = $_POST['text'];
        }
    }
// если Изменяем дату следующего звонка
    if  ($typeQuery==12) {
      $changeColumn = 'DateNextCall';
      $newPerem = $_POST['nextdate'];
    }
// если Изменяем состояние КП
    if  ($typeQuery==13) { 
      $changeColumn = 'KpCondition';
      $newPerem = $_POST['ChangeCondition'];
    }
    // если Изменяем ответственного за КП работника
    if  ($typeQuery==10) { 
      $changeColumn = 'Responsible';
      $newPerem = $_POST['ChangeCondition'];
    }
    if  ($typeQuery==9) { 
      $changeColumn = 'KpImportance';
      $newPerem = $_POST['ChangeCondition'];
    }
    // емли изменяет контракт закрыт/открыт
    if  ($typeQuery==16) { 
      $changeColumn = 'FinishContract';
      $newPerem = $_POST['ChangeCondition'];
    }

$newPerem=htmlspecialchars($newPerem);


// echo "ID = ".$id."<br>";
// echo "Our TExt =".$newPerem."<br>";

$sql = "UPDATE `reestrkp` SET `$changeColumn`= '$newPerem' WHERE `id`='$id'";
$query = $mysqli->query($sql);

if (!$query){
die();
printf("Соединение не удалось: ");
}
;


   //printf($user_login);
 
   $fileLogName = date('Y-m-d'); // создаем имя фаила куда будем писать логи ... каждый день новый файил
    $file = "../logs/".$fileLogName.".txt";
    $fileAll = '../log.txt';
  //    $file = '../log.txt';
      $now_date = date('Y-m-d H:i:s');
      //$temp_var = $now_date." ID=".$id." Столбец: ".$changeColumn."; Изменения :".$newPerem.";\n";
      $temp_var = $now_date." Автор: ".$user_login." ID=".$id." Столбец: ".$changeColumn."; Изменения :".$newPerem.";\n";
      // Пишем содержимое в файл,
      // используя флаг FILE_APPEND для дописывания содержимого в конец файла
      // и флаг LOCK_EX для предотвращения записи данного файла кем-нибудь другим в данное время
      file_put_contents($file, $temp_var, FILE_APPEND | LOCK_EX); // логи по датам
      file_put_contents($fileAll, $temp_var, FILE_APPEND | LOCK_EX); // Все логи подряд

//echo "UPDATE COMMENT <br>";
header ("Location: ..?id=".$id."&typeQuery=".$typeQuery);  // перенаправление на нужную страницу
exit();    // прерываем работу скрипта, чтобы забыл о прошлом

?>