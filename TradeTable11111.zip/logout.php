<?php
setcookie("id", "", time() - 3600*24*30*12, "/");
setcookie("hash", "", time() - 3600*24*30*12, "/",null,null,true); // httponly !!!
// Переадресовываем браузер на страницу проверки нашего скрипта

header ("Location: index.php"); 
?>