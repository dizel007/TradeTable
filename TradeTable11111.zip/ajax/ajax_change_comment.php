<?php
// require_once "../connect11_db.php";
// require_once "../functions/make_arr_from_obj.php";

// $id = $_POST['id'];
// $Our_comment ="Ghbdtn";

//  $sql = "SELECT * FROM reestrkp where id='$id'";
//  $fQuery = $mysqli->query($sql);
//  $arr_name = makeArrayFromObj($fQuery) ;
 
//   foreach ($arr_name as $key => $value) {
//     foreach ($value as $key1 => $value1) {
//         if ($key1 == 'Comment') {
//             $Our_comment = $value1;
//          }
//       }
//    }
// $marker=0;
// echo $marker;
// Echo "GHBDTN";
  
//   echo <<<HTML
//       <div class="dm-overlay" id="win1">
//           <div class="dm-table">
//               <div class="dm-cell">
//                   <div class="dm-modal">
//                       <a href="#close" class="close"></a>
//                       <p>Текстовое содержание : ".$Our_comment."</p>
                      
//                   <form  action="changeDB/update_comment.php?id=";>
//                          <p>Добавить комментарий : </p>
//                                 <p>
//                            <textarea name="text" rows="10" cols="45">$Our_comment</textarea>
//                                 </p>
//                               <p><input type="submit" value="Отправить"></p>
//                             </p>
//                      </form>
//                   </div>
//               </div>
//       </div>
       
// HTML;
?>
