<?php
echo "<script type=\"text/javascript\" src=\"js/ajax_query_comment.js\"></script>";
echo "<script type=\"text/javascript\" src=\"js/modal.js\"></script>";
// маска для ввода телефона
echo "<script type=\"text/javascript\" src=\"js/telephone_mask/jquery-3.3.1.maskedinput.min.js\"></script>";
// маска для ввода телефона
echo "<script type=\"text/javascript\" src=\"js/telephone_mask/telephone_number.js\"></script>";

echo '</body></html>';

$mysqli->close();
?>